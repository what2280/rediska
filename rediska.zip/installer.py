import os
print("""Requirement already satisfied, 
ERROR: Could not find a version that satisfies the requirement sys (from versions: none)
ERROR: No matching distribution found for sys - пример ошибок которых не надо бояться""")

os.system("pip3 install tqdm")
os.system("pip3 install tkinter")
os.system("pip3 install playsound")
os.system("pip3 install colorama")
os.system("clear")
os.system("chmod +x rd")
os.system("chmod +x srd")
print("""установка завершена 
чтобы запустить - ./rd
чтобы запустить программу для администраторов ./srd""")
